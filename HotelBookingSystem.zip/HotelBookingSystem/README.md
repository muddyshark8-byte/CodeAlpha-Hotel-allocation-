# Hotel Booking System

A simple console-based Hotel Room Booking & Management System written in Java.

## Features
- Room categories: Standard, Deluxe, Suite
- Search available rooms (all or by category)
- Make a reservation
- Cancel a reservation
- Payment simulation
- View booking details
- Data is saved permanently using text files (`rooms.txt` and `bookings.txt`)

## How to Compile & Run

1. Open a terminal in this folder
2. Compile all files:
   ```bash
   javac *.java
   ```
3. Run the program:
   ```bash
   java HotelSystem
   ```

## Files
- `Room.java` – Room class
- `Reservation.java` – Reservation / Booking class
- `HotelSystem.java` – Main program + menu + file handling
- `rooms.txt` – Created automatically (stores room data)
- `bookings.txt` – Created automatically (stores reservations)

## Sample Rooms (created on first run)
- 101, 102 → Standard
- 201, 202 → Deluxe
- 301, 302 → Suite
